"""
test_agent.py — Tests for LennyAgent routing, tool dispatch, and session isolation.
"""
import pytest
from unittest.mock import patch, MagicMock

from app.core.agent import LennyAgent, AgentResponse, AgentArtifact


# ------------------------------------------------------------------ #
# Helpers                                                               #
# ------------------------------------------------------------------ #

def _make_agent():
    """Return a LennyAgent with mocked service dependencies."""
    with patch("app.core.agent.LennyAgent.__init__", lambda self: None):
        agent = LennyAgent.__new__(LennyAgent)
    agent._rag = MagicMock()
    agent._ship30 = MagicMock()
    return agent


# ------------------------------------------------------------------ #
# Ollama fallback routing                                               #
# ------------------------------------------------------------------ #

class TestOllamaFallbackRouting:
    """When LLM_PROVIDER=ollama, routing is intent-based."""

    def setup_method(self):
        self.agent = _make_agent()
        self.agent._rag.retrieve.return_value = []
        self.agent._rag.answer_question.return_value = ("Test answer.", [])
        self.agent._ship30.return_value = {
            "topic": "activation",
            "content": "## Essay content here",
            "word_count": 3,
            "artifact_type": "ship30_essay",
            "metadata": {},
        }

    @patch("app.core.agent.llm")
    def test_rag_query_calls_answer_question(self, mock_llm):
        mock_llm.provider = "ollama"
        resp = self.agent._run_ollama_fallback(
            "What does Lenny say about retention?",
            [{"role": "user", "content": "What does Lenny say about retention?"}]
        )
        self.agent._rag.answer_question.assert_called_once()
        assert resp.artifact.artifact_type == "rag_answer"
        assert "rag_retrieve" in resp.tool_calls_made

    @patch("app.core.agent.llm")
    def test_ship30_query_routes_to_ship30(self, mock_llm):
        mock_llm.provider = "ollama"
        resp = self.agent._run_ollama_fallback(
            "Write an atomic essay on activation",
            [{"role": "user", "content": "Write an atomic essay on activation"}]
        )
        self.agent._ship30.assert_called_once()
        assert resp.artifact.artifact_type == "ship30_essay"
        assert "ship30_write" in resp.tool_calls_made

    @patch("app.core.agent.llm")
    def test_ship30_trigger_words(self, mock_llm):
        mock_llm.provider = "ollama"
        triggers = [
            "ship 30 essay on pricing",
            "atomic essay about growth",
            "write an essay on onboarding",
            "essay about retention",
        ]
        for query in triggers:
            self.agent._ship30.reset_mock()
            self.agent._run_ollama_fallback(query, [])
            self.agent._ship30.assert_called_once(), f"ship30 not called for: {query}"


# ------------------------------------------------------------------ #
# Tool dispatch                                                         #
# ------------------------------------------------------------------ #

class TestToolDispatch:
    def setup_method(self):
        self.agent = _make_agent()
        self.agent._rag.retrieve.return_value = [
            {"text": "Retention is key.", "source": "Episode 1", "chunk_index": 0, "score": 0.8}
        ]
        self.agent._ship30.return_value = {
            "topic": "activation", "content": "Essay body.", "word_count": 2,
            "artifact_type": "ship30_essay", "metadata": {},
        }

    def test_rag_retrieve_returns_context(self):
        sources = []
        result = self.agent._dispatch_tool("rag_retrieve", {"query": "retention"}, sources)
        assert "Retention is key." in result
        assert len(sources) == 1
        assert sources[0]["source"] == "Episode 1"

    def test_rag_retrieve_empty_returns_message(self):
        self.agent._rag.retrieve.return_value = []
        sources = []
        result = self.agent._dispatch_tool("rag_retrieve", {"query": "xyz"}, sources)
        assert "No relevant content" in result
        assert sources == []

    def test_ship30_write_dispatch(self):
        sources = []
        result = self.agent._dispatch_tool(
            "ship30_write", {"topic": "activation", "context": None}, sources
        )
        assert "Essay body." in result

    def test_generate_artifact_dispatch(self):
        import json
        sources = []
        result = self.agent._dispatch_tool(
            "generate_artifact",
            {"artifact_type": "rag_answer", "title": "Test", "content": "Content", "format": "markdown"},
            sources
        )
        parsed = json.loads(result)
        assert parsed["artifact_type"] == "rag_answer"
        assert parsed["title"] == "Test"

    def test_unknown_tool_graceful(self):
        sources = []
        result = self.agent._dispatch_tool("nonexistent_tool", {}, sources)
        assert "Unknown tool" in result


# ------------------------------------------------------------------ #
# Session isolation                                                     #
# ------------------------------------------------------------------ #

class TestSessionIsolation:
    """History passed to agent must be session-scoped — tested via chat() signature."""

    def setup_method(self):
        self.agent = _make_agent()
        self.agent._rag.answer_question.return_value = ("Answer", [])
        self.agent._rag.retrieve.return_value = []

    @patch("app.core.agent.llm")
    def test_different_histories_produce_independent_responses(self, mock_llm):
        mock_llm.provider = "ollama"
        history_a = [{"role": "user", "content": "session A context"}]
        history_b = []  # empty session

        resp_a = self.agent._run_ollama_fallback("What is activation?", history_a)
        resp_b = self.agent._run_ollama_fallback("What is activation?", history_b)

        # Both produce answers — crucially, they use different histories
        # (the agent isolates via the history parameter, not global state)
        assert resp_a is not resp_b

    @patch("app.core.agent.llm")
    def test_empty_history_does_not_carry_over(self, mock_llm):
        mock_llm.provider = "ollama"
        # Session A gets a context
        resp_a = self.agent._run_ollama_fallback(
            "Tell me about retention",
            [{"role": "user", "content": "I am user A"}]
        )
        # Session B with no history
        resp_b = self.agent._run_ollama_fallback(
            "Tell me about retention",
            []
        )
        # Verify agent._rag was called independently each time
        assert self.agent._rag.answer_question.call_count == 2
