"""
test_security.py — Artifact Viewer security behavior tests.

Security strategy documented:
  - Artifacts are rendered in <iframe sandbox="allow-scripts"> (no allow-same-origin)
  - Content is sanitized with DOMPurify (ALLOWED_TAGS=[], ALLOWED_ATTR=[]) before
    being placed in srcdoc
  - Because allow-same-origin is absent, the iframe cannot access the parent window's
    localStorage, cookies, or DOM — even with allow-scripts
  - DOMPurify strips all HTML/JS before the srcdoc is composed; allow-scripts in the
    sandbox only permits inline scripts within the srcdoc document itself, not cross-origin access
  - Permitted: plain text, markdown-rendered HTML via marked.js (pre-sanitized)
  - Blocked: <script> tags from AI output, onerror handlers, data: URIs, form submissions

These tests verify the HTML contract and that sanitization removes attack vectors.
"""

import re
import pytest


# ------------------------------------------------------------------ #
# Read the actual HTML file                                             #
# ------------------------------------------------------------------ #

def _load_html() -> str:
    with open("frontend/index.html", "r", encoding="utf-8") as f:
        return f.read()


# ------------------------------------------------------------------ #
# iframe sandbox policy                                                 #
# ------------------------------------------------------------------ #

class TestIframeSandbox:
    def test_iframe_has_sandbox_attribute(self):
        """Artifact iframe must have sandbox attribute."""
        html = _load_html()
        assert 'sandbox=' in html

    def test_sandbox_does_not_include_allow_same_origin(self):
        """
        CRITICAL: allow-same-origin would let the iframe access the parent
        window's origin, defeating the entire sandboxing purpose.
        """
        html = _load_html()
        # Find all sandbox attribute values
        sandboxes = re.findall(r'sandbox=["\']([^"\']*)["\']', html)
        for s in sandboxes:
            assert 'allow-same-origin' not in s, (
                f"SECURITY VIOLATION: sandbox contains allow-same-origin: '{s}'"
            )

    def test_sandbox_attribute_value(self):
        """Sandbox should only have allow-scripts (for marked.js rendering)."""
        html = _load_html()
        sandboxes = re.findall(r'sandbox=["\']([^"\']*)["\']', html)
        assert len(sandboxes) > 0, "No sandbox attribute found on any element"
        for s in sandboxes:
            tokens = s.split()
            assert 'allow-scripts' in tokens

    def test_csp_header_present(self):
        """Content-Security-Policy meta tag should be present."""
        html = _load_html()
        assert 'Content-Security-Policy' in html


# ------------------------------------------------------------------ #
# DOMPurify usage                                                       #
# ------------------------------------------------------------------ #

class TestDOMPurify:
    def test_dompurify_loaded_from_cdn(self):
        html = _load_html()
        assert 'dompurify' in html.lower()
        assert 'cdn.jsdelivr.net' in html

    def test_eschtml_uses_dompurify_sanitize(self):
        """escHtml must call DOMPurify.sanitize, not a manual regex escape."""
        html = _load_html()
        # Find the escHtml function
        match = re.search(r'function escHtml\(.*?\}', html, re.DOTALL)
        assert match, "escHtml function not found"
        func_body = match.group(0)
        assert 'DOMPurify.sanitize' in func_body, (
            "escHtml must use DOMPurify.sanitize, not manual regex escaping"
        )
        # Must NOT use the old naive regex approach
        assert ".replace(/&/g,'&amp;')" not in func_body

    def test_dompurify_strips_all_tags(self):
        """DOMPurify call must use ALLOWED_TAGS: [] to strip all HTML."""
        html = _load_html()
        assert "ALLOWED_TAGS" in html
        assert "ALLOWED_TAGS: []" in html or "ALLOWED_TAGS:[]" in html.replace(" ", "")

    def test_srcdoc_uses_dompurify_sanitize(self):
        """The iframe srcdoc must be composed with DOMPurify.sanitize, not raw content."""
        html = _load_html()
        # Verify the srcdoc construction line calls DOMPurify.sanitize
        assert 'DOMPurify.sanitize(content)' in html


# ------------------------------------------------------------------ #
# Python-side sanitization contract (ingest / API layer)               #
# ------------------------------------------------------------------ #

class TestPythonSideContracts:
    """
    Test that the ingest cleaning pipeline strips HTML tags that
    could be injected into the knowledge base from transcript files.
    """

    def test_clean_text_strips_script_tags(self):
        import sys, os
        sys.path.insert(0, os.path.abspath('.'))
        from scripts.ingest import clean_text
        malicious = "Normal text <script>alert('xss')</script> more text"
        result = clean_text(malicious)
        assert '<script>' not in result
        assert 'alert' not in result
        assert 'Normal text' in result

    def test_clean_text_strips_img_onerror(self):
        from scripts.ingest import clean_text
        malicious = 'Text <img src=x onerror="steal()"> end'
        result = clean_text(malicious)
        assert 'onerror' not in result
        assert '<img' not in result

    def test_clean_text_strips_inline_event_handlers(self):
        from scripts.ingest import clean_text
        malicious = 'Text <a href="#" onclick="evil()">click</a> end'
        result = clean_text(malicious)
        assert 'onclick' not in result

    def test_clean_text_preserves_content(self):
        from scripts.ingest import clean_text
        good = "Lenny says activation is the aha moment."
        result = clean_text(good)
        assert "activation" in result
        assert "aha moment" in result
