"""
test_rag.py — Tests for RAGService: retrieval, low-confidence, source tracing.
"""
import pytest
from unittest.mock import patch, MagicMock, PropertyMock

from app.services.rag import RAGService, LOW_CONFIDENCE_REPLY, CONFIDENCE_THRESHOLD


@pytest.fixture
def rag_stub():
    """RAGService with ChromaDB disabled (uses stub KB)."""
    svc = RAGService.__new__(RAGService)
    svc._collection = None
    svc._chroma_available = False
    return svc


@pytest.fixture
def rag_chroma():
    """RAGService with a mocked ChromaDB collection."""
    svc = RAGService.__new__(RAGService)
    svc._chroma_available = True
    mock_col = MagicMock()
    mock_col.count.return_value = 10
    svc._collection = mock_col
    return svc, mock_col


# ------------------------------------------------------------------ #
# Retrieval                                                             #
# ------------------------------------------------------------------ #

class TestRetrieval:
    def test_stub_retrieve_returns_docs(self, rag_stub):
        docs = rag_stub.retrieve("activation")
        assert isinstance(docs, list)
        assert len(docs) > 0

    def test_stub_docs_have_required_keys(self, rag_stub):
        docs = rag_stub.retrieve("retention")
        for d in docs:
            assert "text" in d
            assert "source" in d
            assert "chunk_index" in d
            assert "score" in d

    def test_chroma_retrieve_called_with_query(self, rag_chroma):
        svc, mock_col = rag_chroma
        mock_col.query.return_value = {
            "documents": [["Retention is key."]],
            "metadatas": [[{"source": "Episode 1", "chunk_index": 0}]],
            "distances": [[0.2]],
        }
        docs = svc.retrieve("retention")
        mock_col.query.assert_called_once()
        assert docs[0]["source"] == "Episode 1"
        assert docs[0]["score"] == pytest.approx(0.8)  # 1.0 - 0.2

    def test_chroma_empty_collection_falls_back_to_stub(self, rag_chroma):
        svc, mock_col = rag_chroma
        mock_col.count.return_value = 0
        docs = svc.retrieve("activation")
        # Fallback to stub
        assert len(docs) > 0
        mock_col.query.assert_not_called()

    def test_source_tracing_metadata_preserved(self, rag_chroma):
        svc, mock_col = rag_chroma
        mock_col.query.return_value = {
            "documents": [["Text chunk."]],
            "metadatas": [[{"source": "Newsletter #42", "chunk_index": 3}]],
            "distances": [[0.15]],
        }
        docs = svc.retrieve("growth")
        assert docs[0]["chunk_index"] == 3
        assert "Newsletter" in docs[0]["source"]


# ------------------------------------------------------------------ #
# Low-confidence / empty retrieval                                      #
# ------------------------------------------------------------------ #

class TestLowConfidence:
    def test_empty_retrieval_returns_disclaimer(self, rag_stub):
        """If no docs returned, must not hallucinate."""
        with patch.object(rag_stub, 'retrieve', return_value=[]):
            answer, sources = rag_stub.answer_question("obscure topic")
        assert answer == LOW_CONFIDENCE_REPLY
        assert sources == []

    def test_below_threshold_score_returns_disclaimer(self, rag_stub):
        """If all scores below CONFIDENCE_THRESHOLD, must decline."""
        low_score_docs = [
            {"text": "Some text.", "source": "ep1", "chunk_index": 0,
             "score": CONFIDENCE_THRESHOLD - 0.01}
        ]
        with patch.object(rag_stub, 'retrieve', return_value=low_score_docs):
            answer, sources = rag_stub.answer_question("obscure topic")
        assert answer == LOW_CONFIDENCE_REPLY
        assert sources == []

    def test_above_threshold_calls_llm(self, rag_stub):
        """High-confidence retrieval should call LLM and return sources."""
        high_score_docs = [
            {"text": "Retention is driven by habit.", "source": "ep12",
             "chunk_index": 0, "score": 0.85}
        ]
        with patch.object(rag_stub, 'retrieve', return_value=high_score_docs):
            with patch("app.services.rag.llm") as mock_llm:
                mock_llm.generate.return_value = "Retention answer."
                answer, sources = rag_stub.answer_question("What drives retention?")
        assert answer == "Retention answer."
        assert len(sources) == 1
        assert sources[0]["source"] == "ep12"

    def test_sources_contain_required_fields(self, rag_stub):
        docs = [
            {"text": "Text.", "source": "Episode 5", "chunk_index": 2, "score": 0.9}
        ]
        with patch.object(rag_stub, 'retrieve', return_value=docs):
            with patch("app.services.rag.llm") as mock_llm:
                mock_llm.generate.return_value = "Answer."
                _, sources = rag_stub.answer_question("Question?")
        assert "source" in sources[0]
        assert "chunk_index" in sources[0]
        assert "score" in sources[0]
