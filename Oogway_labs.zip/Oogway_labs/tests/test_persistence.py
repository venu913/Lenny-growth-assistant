"""
test_persistence.py — PostgreSQL model persistence tests (SQLite in-memory for CI).
"""
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Session, Message, Artifact

TEST_URL = "sqlite:///./test_persist.db"
engine = create_engine(TEST_URL, connect_args={"check_same_thread": False})
Base.metadata.create_all(bind=engine)
SessionLocal = sessionmaker(bind=engine)


@pytest.fixture
def db():
    session = SessionLocal()
    yield session
    session.rollback()
    session.close()


# ------------------------------------------------------------------ #
# Session                                                               #
# ------------------------------------------------------------------ #

class TestSessionPersistence:
    def test_create_session(self, db):
        s = Session()
        db.add(s)
        db.commit()
        fetched = db.query(Session).filter(Session.id == s.id).first()
        assert fetched is not None

    def test_session_id_is_uuid(self, db):
        s = Session()
        db.add(s)
        db.commit()
        assert len(s.id) == 36 and s.id.count('-') == 4

    def test_session_created_at_set(self, db):
        s = Session()
        db.add(s)
        db.commit()
        assert s.created_at is not None


# ------------------------------------------------------------------ #
# Message                                                               #
# ------------------------------------------------------------------ #

class TestMessagePersistence:
    def test_message_linked_to_session(self, db):
        s = Session()
        db.add(s)
        db.commit()
        m = Message(session_id=s.id, role="user", content="Hello")
        db.add(m)
        db.commit()
        fetched = db.query(Message).filter(Message.session_id == s.id).all()
        assert len(fetched) == 1
        assert fetched[0].content == "Hello"

    def test_multiple_messages_ordered_by_created_at(self, db):
        s = Session()
        db.add(s)
        db.commit()
        for i in range(3):
            db.add(Message(session_id=s.id, role="user", content=f"msg {i}"))
        db.commit()
        s_fetched = db.query(Session).filter(Session.id == s.id).first()
        assert len(s_fetched.messages) == 3

    def test_session_relationship_loads_messages(self, db):
        s = Session()
        db.add(s)
        db.commit()
        db.add(Message(session_id=s.id, role="assistant", content="Hi"))
        db.commit()
        s_fetched = db.query(Session).filter(Session.id == s.id).first()
        assert s_fetched.messages[0].role == "assistant"


# ------------------------------------------------------------------ #
# Artifact                                                              #
# ------------------------------------------------------------------ #

class TestArtifactPersistence:
    def test_artifact_saved_and_retrieved(self, db):
        s = Session()
        db.add(s)
        db.commit()
        a = Artifact(
            session_id=s.id,
            artifact_type="rag_answer",
            format="markdown",
            title="Test Artifact",
            content="# Hello\n\nThis is content.",
            sources=[{"source": "Episode 1", "chunk_index": 0}],
        )
        db.add(a)
        db.commit()
        fetched = db.query(Artifact).filter(Artifact.session_id == s.id).first()
        assert fetched is not None
        assert fetched.artifact_type == "rag_answer"
        assert fetched.title == "Test Artifact"
        assert "Hello" in fetched.content

    def test_artifact_sources_stored_as_json(self, db):
        s = Session()
        db.add(s)
        db.commit()
        sources = [{"source": "Newsletter #5", "chunk_index": 2, "score": 0.8}]
        a = Artifact(
            session_id=s.id,
            artifact_type="ship30_essay",
            format="markdown",
            title="Essay",
            content="Content.",
            sources=sources,
        )
        db.add(a)
        db.commit()
        fetched = db.query(Artifact).filter(Artifact.id == a.id).first()
        assert isinstance(fetched.sources, list)
        assert fetched.sources[0]["source"] == "Newsletter #5"

    def test_artifact_linked_to_session_relationship(self, db):
        s = Session()
        db.add(s)
        db.commit()
        a = Artifact(
            session_id=s.id,
            artifact_type="markdown",
            format="markdown",
            title="A",
            content="Content",
            sources=[],
        )
        db.add(a)
        db.commit()
        s_fetched = db.query(Session).filter(Session.id == s.id).first()
        assert len(s_fetched.artifacts) == 1

    def test_session_isolation_artifacts(self, db):
        """Artifacts from session A must not appear in session B."""
        s_a = Session()
        s_b = Session()
        db.add_all([s_a, s_b])
        db.commit()
        db.add(Artifact(
            session_id=s_a.id, artifact_type="markdown",
            format="markdown", title="A artifact", content="A", sources=[]
        ))
        db.commit()
        arts_b = db.query(Artifact).filter(Artifact.session_id == s_b.id).all()
        assert arts_b == []


# ------------------------------------------------------------------ #
# LLM provider switching                                                #
# ------------------------------------------------------------------ #

class TestProviderSwitching:
    def test_provider_name_ollama(self):
        import os
        from unittest.mock import patch
        with patch.dict(os.environ, {"LLM_PROVIDER": "ollama", "OLLAMA_MODEL": "llama3"}):
            from app.core.llm import LLMProvider
            p = LLMProvider()
            assert "Ollama" in p.get_provider_name()
            assert "llama3" in p.get_provider_name()

    def test_provider_name_anthropic(self):
        import os
        from unittest.mock import patch
        with patch.dict(os.environ, {"LLM_PROVIDER": "anthropic"}):
            from app.core.llm import LLMProvider
            p = LLMProvider()
            assert "Anthropic" in p.get_provider_name()

    def test_missing_api_key_raises(self):
        import os
        from unittest.mock import patch
        from app.core.llm import LLMProvider, MissingAPIKeyError
        with patch.dict(os.environ, {"LLM_PROVIDER": "anthropic", "ANTHROPIC_API_KEY": ""}):
            p = LLMProvider()
            with pytest.raises(MissingAPIKeyError):
                p._call_anthropic("test prompt", "")

    def test_ollama_unavailable_raises(self):
        import os
        from unittest.mock import patch
        import requests
        from app.core.llm import LLMProvider, OllamaUnavailableError
        with patch.dict(os.environ, {"LLM_PROVIDER": "ollama", "OLLAMA_URL": "http://localhost:19999/api/generate"}):
            p = LLMProvider()
            with patch("requests.post", side_effect=requests.exceptions.ConnectionError()):
                with pytest.raises(OllamaUnavailableError):
                    p._call_ollama("prompt", "")
