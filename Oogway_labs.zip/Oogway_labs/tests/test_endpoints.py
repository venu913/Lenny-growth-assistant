"""
test_endpoints.py — FastAPI endpoint tests with session isolation and provider checks.
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from unittest.mock import patch, MagicMock

from app.main import app, get_db
from app.models import Base
from app.core.agent import AgentResponse, AgentArtifact

# ------------------------------------------------------------------ #
# Test DB                                                               #
# ------------------------------------------------------------------ #

TEST_URL = "sqlite:///./test_main.db"
test_engine = create_engine(TEST_URL, connect_args={"check_same_thread": False})
TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)
Base.metadata.create_all(bind=test_engine)


def override_get_db():
    db = TestingSession()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)


# ------------------------------------------------------------------ #
# Session endpoints                                                     #
# ------------------------------------------------------------------ #

class TestSessionEndpoints:
    def test_create_session_returns_uuid(self):
        res = client.post("/sessions")
        assert res.status_code == 200
        sid = res.json()["session_id"]
        assert len(sid) == 36

    def test_get_messages_empty_session(self):
        sid = client.post("/sessions").json()["session_id"]
        res = client.get(f"/sessions/{sid}/messages")
        assert res.status_code == 200
        assert res.json() == []

    def test_add_message_and_retrieve(self):
        sid = client.post("/sessions").json()["session_id"]
        client.post(f"/sessions/{sid}/messages", json={"role": "user", "content": "Hello"})
        msgs = client.get(f"/sessions/{sid}/messages").json()
        assert len(msgs) == 1
        assert msgs[0]["content"] == "Hello"

    def test_invalid_session_404(self):
        res = client.get("/sessions/nonexistent/messages")
        assert res.status_code == 404

    def test_add_message_to_invalid_session_404(self):
        res = client.post("/sessions/fake-id/messages",
                          json={"role": "user", "content": "test"})
        assert res.status_code == 404


# ------------------------------------------------------------------ #
# /api/provider                                                         #
# ------------------------------------------------------------------ #

class TestProviderEndpoint:
    def test_provider_endpoint_returns_name(self):
        res = client.get("/api/provider")
        assert res.status_code == 200
        data = res.json()
        assert "provider" in data
        assert isinstance(data["provider"], str)
        assert len(data["provider"]) > 0

    @patch("app.main.llm")
    def test_provider_shows_ollama(self, mock_llm):
        mock_llm.get_provider_name.return_value = "Ollama (llama3)"
        res = client.get("/api/provider")
        assert "Ollama" in res.json()["provider"]

    @patch("app.main.llm")
    def test_provider_shows_anthropic(self, mock_llm):
        mock_llm.get_provider_name.return_value = "Anthropic Claude"
        res = client.get("/api/provider")
        assert "Anthropic" in res.json()["provider"]


# ------------------------------------------------------------------ #
# /api/chat — session validation                                        #
# ------------------------------------------------------------------ #

class TestChatEndpoint:
    def _mock_agent_response(self):
        return AgentResponse(
            answer="Retention is about habit formation.",
            sources=[{"source": "Episode 1", "chunk_index": 0, "score": 0.9}],
            artifact=AgentArtifact(
                artifact_type="rag_answer",
                title="Answer",
                content="Retention is about habit formation.",
                format="markdown",
                sources=[],
            ),
            tool_calls_made=["rag_retrieve"],
        )

    def test_chat_requires_valid_session_id(self):
        """Chat with nonexistent session must return 404."""
        res = client.post("/api/chat",
                          json={"session_id": "nonexistent-id", "query": "What is activation?"})
        assert res.status_code == 404

    def test_chat_returns_answer_and_sources(self):
        sid = client.post("/sessions").json()["session_id"]
        with patch("app.main.lenny_agent") as mock_agent:
            mock_agent.chat.return_value = self._mock_agent_response()
            res = client.post("/api/chat",
                              json={"session_id": sid, "query": "What is retention?"})
        assert res.status_code == 200
        data = res.json()
        assert "answer" in data
        assert "sources" in data
        assert "session_id" in data
        assert data["session_id"] == sid

    def test_chat_persists_messages(self):
        """After /api/chat, session should have 2 messages (user + assistant)."""
        sid = client.post("/sessions").json()["session_id"]
        with patch("app.main.lenny_agent") as mock_agent:
            mock_agent.chat.return_value = self._mock_agent_response()
            client.post("/api/chat",
                        json={"session_id": sid, "query": "Tell me about activation"})
        msgs = client.get(f"/sessions/{sid}/messages").json()
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["role"] == "assistant"

    def test_session_isolation(self):
        """Messages from session A must NOT appear in session B."""
        sid_a = client.post("/sessions").json()["session_id"]
        sid_b = client.post("/sessions").json()["session_id"]

        with patch("app.main.lenny_agent") as mock_agent:
            mock_agent.chat.return_value = self._mock_agent_response()
            client.post("/api/chat",
                        json={"session_id": sid_a, "query": "Session A question"})

        msgs_b = client.get(f"/sessions/{sid_b}/messages").json()
        assert msgs_b == [], "Session B must not contain Session A's messages"

    def test_history_is_session_scoped(self):
        """Agent.chat() must be called with only the current session's history."""
        sid_a = client.post("/sessions").json()["session_id"]
        sid_b = client.post("/sessions").json()["session_id"]

        # Add a message to session A
        client.post(f"/sessions/{sid_a}/messages",
                    json={"role": "user", "content": "Private A context"})

        with patch("app.main.lenny_agent") as mock_agent:
            mock_agent.chat.return_value = self._mock_agent_response()
            client.post("/api/chat",
                        json={"session_id": sid_b, "query": "Question in B"})

            # Inspect what history was passed to agent.chat
            call_kwargs = mock_agent.chat.call_args[1]
            history = call_kwargs.get("history", [])
            history_contents = [m.get("content", "") for m in history]
            assert "Private A context" not in history_contents


# ------------------------------------------------------------------ #
# /health                                                               #
# ------------------------------------------------------------------ #

def test_health_check():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"
