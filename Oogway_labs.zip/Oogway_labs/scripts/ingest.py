"""
ingest.py — Transcript ingestion pipeline for The Lenny Growth Assistant.

Pipeline:
  1. Discover .txt files in the transcript directory
  2. Clean: strip HTML, normalize whitespace, remove speaker-label noise
  3. Extract metadata from filename conventions:
       ep123_guest_name.txt        → episode, guest
       newsletter_042_topic.txt    → newsletter issue, topic
       anything_else.txt           → generic content
  4. Chunk with sentence-boundary splitting + configurable overlap
  5. Embed via ChromaDB default embedding (all-MiniLM-L6-v2 via sentence-transformers)
  6. Upsert with deterministic MD5 IDs (safe re-ingestion)
  7. Store rich per-chunk metadata for source tracing

Usage:
    python scripts/ingest.py --dir agent_transcripts/ [OPTIONS]

Options:
    --dir          Source directory of .txt transcripts  (default: agent_transcripts/)
    --chunk-size   Max characters per chunk              (default: 400)
    --overlap      Character overlap between chunks      (default: 50)
    --collection   ChromaDB collection name              (default: lenny_transcripts)
    --db-path      ChromaDB persistent storage path      (default: ./chroma_db)

Re-running is safe: existing chunks are updated in-place via upsert.
"""

import os
import re
import argparse
import hashlib


# ------------------------------------------------------------------ #
# Text cleaning                                                         #
# ------------------------------------------------------------------ #

def clean_text(text: str) -> str:
    """
    Remove HTML tags, normalize whitespace, strip speaker-label noise.
    Speaker patterns: "LENNY:", "GUEST:", "00:12:34 GUEST:", timestamps.
    """
    # Strip HTML tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Remove timestamps (HH:MM:SS or MM:SS)
    text = re.sub(r'\b\d{1,2}:\d{2}(?::\d{2})?\b', '', text)
    # Remove speaker labels: ALL_CAPS_WORD followed by colon
    text = re.sub(r'\b[A-Z][A-Z\s]{2,}:\s*', '', text)
    # Normalize whitespace
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


# ------------------------------------------------------------------ #
# Metadata extraction                                                   #
# ------------------------------------------------------------------ #

def extract_metadata(filename: str) -> dict:
    """
    Parse metadata from filename conventions.

    Supported patterns:
      ep{num}_{guest}.txt              → {"content_type": "episode", "episode_num": num, "guest": guest}
      episode_{num}_{guest}.txt        → same
      newsletter_{num}_{topic}.txt     → {"content_type": "newsletter", "issue_num": num, "topic": topic}
      nl_{num}_{topic}.txt             → same
      {anything}.txt                   → {"content_type": "transcript"}
    """
    base = os.path.splitext(filename)[0].lower()
    meta = {"source_file": filename, "content_type": "transcript", "episode_num": None,
            "issue_num": None, "guest": None, "topic": None}

    ep_match = re.match(r'^ep(?:isode)?[_\-]?(\d+)[_\-]?(.*)$', base)
    nl_match = re.match(r'^(?:newsletter|nl)[_\-]?(\d+)[_\-]?(.*)$', base)

    if ep_match:
        meta["content_type"] = "episode"
        meta["episode_num"] = int(ep_match.group(1))
        meta["guest"] = ep_match.group(2).replace('_', ' ').strip() or None
    elif nl_match:
        meta["content_type"] = "newsletter"
        meta["issue_num"] = int(nl_match.group(1))
        meta["topic"] = nl_match.group(2).replace('_', ' ').strip() or None

    return meta


# ------------------------------------------------------------------ #
# Chunking                                                              #
# ------------------------------------------------------------------ #

def chunk_text(text: str, chunk_size: int, overlap: int) -> list[str]:
    """
    Split text into chunks with sentence-boundary alignment and overlap.
    """
    text = text.strip()
    if not text:
        return []

    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            # Walk back to nearest sentence boundary (. ! ?)
            boundary = max(
                text.rfind('. ', start, end),
                text.rfind('! ', start, end),
                text.rfind('? ', start, end),
            )
            if boundary > start + overlap:
                end = boundary + 1  # include the period
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)

    return chunks


# ------------------------------------------------------------------ #
# Deterministic ID                                                      #
# ------------------------------------------------------------------ #

def make_id(source: str, chunk_index: int) -> str:
    raw = f"{source}::chunk::{chunk_index}"
    return hashlib.md5(raw.encode()).hexdigest()


# ------------------------------------------------------------------ #
# Ingest                                                                #
# ------------------------------------------------------------------ #

def ingest(
    directory: str,
    chunk_size: int,
    overlap: int,
    collection_name: str,
    db_path: str,
) -> None:
    import chromadb

    client = chromadb.PersistentClient(path=db_path)
    collection = client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},
    )

    txt_files = [f for f in os.listdir(directory) if f.endswith('.txt')]
    if not txt_files:
        print(f"No .txt files found in '{directory}'")
        return

    total_chunks = 0
    total_files = 0

    for fname in sorted(txt_files):
        fpath = os.path.join(directory, fname)
        with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
            raw = f.read()

        cleaned = clean_text(raw)
        if not cleaned:
            print(f"  ⚠ {fname}: empty after cleaning, skipping")
            continue

        file_meta = extract_metadata(fname)
        source_label = fname  # used as the human-readable source citation

        # Determine display source
        if file_meta["content_type"] == "episode" and file_meta["episode_num"]:
            ep = file_meta["episode_num"]
            guest = file_meta.get("guest") or ""
            source_label = f"Episode {ep}" + (f" — {guest.title()}" if guest else "")
        elif file_meta["content_type"] == "newsletter" and file_meta["issue_num"]:
            issue = file_meta["issue_num"]
            topic = file_meta.get("topic") or ""
            source_label = f"Newsletter #{issue}" + (f" — {topic.title()}" if topic else "")

        chunks = chunk_text(cleaned, chunk_size, overlap)
        if not chunks:
            print(f"  ⚠ {fname}: no chunks produced")
            continue

        ids = [make_id(fname, i) for i in range(len(chunks))]
        metadatas = [
            {
                "source": source_label,
                "source_file": fname,
                "chunk_index": i,
                "content_type": file_meta["content_type"],
                "episode_num": str(file_meta.get("episode_num") or ""),
                "issue_num": str(file_meta.get("issue_num") or ""),
                "guest": str(file_meta.get("guest") or ""),
                "topic": str(file_meta.get("topic") or ""),
                "word_count": len(chunks[i].split()),
            }
            for i in range(len(chunks))
        ]

        # Upsert in batches of 100
        batch_size = 100
        for i in range(0, len(chunks), batch_size):
            collection.upsert(
                documents=chunks[i:i + batch_size],
                ids=ids[i:i + batch_size],
                metadatas=metadatas[i:i + batch_size],
            )

        total_chunks += len(chunks)
        total_files += 1
        print(f"  ✓ {source_label}: {len(chunks)} chunks ({len(cleaned.split())} words)")

    print(
        f"\n{'─'*50}\n"
        f"Ingested {total_chunks} chunks from {total_files} files → '{collection_name}'\n"
        f"ChromaDB path: {os.path.abspath(db_path)}\n"
    )


# ------------------------------------------------------------------ #
# CLI                                                                   #
# ------------------------------------------------------------------ #

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Ingest Lenny transcripts into ChromaDB")
    parser.add_argument('--dir', default='agent_transcripts', help='Directory of .txt transcripts')
    parser.add_argument('--chunk-size', type=int, default=400, help='Max chars per chunk')
    parser.add_argument('--overlap', type=int, default=50, help='Char overlap between chunks')
    parser.add_argument('--collection', default='lenny_transcripts', help='ChromaDB collection')
    parser.add_argument('--db-path', default='./chroma_db', help='ChromaDB storage path')
    args = parser.parse_args()

    ingest(
        directory=args.dir,
        chunk_size=args.chunk_size,
        overlap=args.overlap,
        collection_name=args.collection,
        db_path=args.db_path,
    )
