# PRD: The Lenny Growth Assistant

## Overview
A conversational AI assistant grounded in Lenny Rachitsky's podcast episodes and newsletters, with pluggable "skills" for structured content generation.

---

## Problem Statement
Product managers and growth practitioners lack a fast, grounded interface to query Lenny's knowledge base and generate actionable content without hours of manual research.

---

## Goals
- Sub-5-second responses from a RAG pipeline over Lenny's corpus
- Pluggable skill system (starting with Ship 30 for 30)
- Full artifact lifecycle: generate → view → copy → export

---

## User Stories

| ID | As a... | I want to... | So that... |
|----|---------|-------------|------------|
| U1 | PM | Ask "what does Lenny say about retention?" | I get a cited answer in seconds |
| U2 | Founder | Generate a Ship 30 Atomic Essay on activation | I can publish to Twitter without writer's block |
| U3 | Any user | View all generated artifacts in a panel | I can reference and copy them later |

---

## Non-Goals (v1)
- Multi-user auth
- PDF export of artifacts
- Transcript audio playback

---

## Success Metrics
- P90 response latency < 5s (local Ollama), < 3s (cloud)
- Citation accuracy ≥ 90% (manual review of 50 queries)
- Artifact copy-rate ≥ 40% of generated artifacts

---

## Skills Roadmap

| Skill | Status |
|-------|--------|
| RAG Q&A | ✅ Implemented (Anthropic Tool/Ollama Routing) |
| Ship 30 for 30 Essay | ✅ Implemented (Native Tool) |
| PRD Generator | 🔜 Phase 4 |
| Competitor Analysis | 🔜 Phase 4 |
