# Architecture: The Lenny Growth Assistant

## Stack

| Layer | Tech |
|-------|------|
| API | FastAPI (Python 3.11) |
| DB | PostgreSQL 15 (sessions, messages) |
| Vector Store | ChromaDB (Phase 2+) |
| LLM | Ollama (local) / Anthropic Claude (cloud) |
| Frontend | Vanilla HTML/JS (zero build step) |
| Container | Docker Compose |

---

## Component Diagram

```
Browser (frontend/index.html)
        │ (session_id)
        ▼
FastAPI (app/main.py)
   ├── /sessions, /messages          → PostgreSQL
   ├── /api/chat                     → LennyAgent (app/core/agent.py)
   └── /api/chat/ship30              → LennyAgent (app/core/agent.py)
        │
        ▼
  LennyAgent (Tool-Calling Router)
   ├── rag_retrieve (Tool)           → RAGService → ChromaDB + LLM
   ├── ship30_write (Tool)           → Ship30Service → LLM
   └── generate_artifact (Tool)      → Structures response
        │
        ▼
  LLMProvider (app/core/llm.py)
   ├── _call_ollama()  [LLM_PROVIDER=ollama] (Prompt fallback)
   └── _call_anthropic() [LLM_PROVIDER=anthropic] (Native tool calling)
```

---

## Data Flow: RAG Query

1. User sends `POST /api/chat { query }`
2. `RAGService.retrieve(query)` — vector similarity over Lenny transcript chunks
3. Top-k docs injected into system prompt with source citations
4. `LLMProvider.generate()` → grounded answer + citations returned
5. Artifact stored in frontend Artifact Panel

---

## Data Flow: Ship 30 Essay

1. User sends `POST /api/chat/ship30 { topic }`
2. `generate_ship30_essay(topic)` builds structured prompt
3. LLM returns: Atomic Essay + Twitter hook + 30-day topic ladder
4. Response rendered as Artifact card in UI

---

## LLM Toggle

Set via environment variable:

```
LLM_PROVIDER=ollama   # default, uses OLLAMA_URL + OLLAMA_MODEL
LLM_PROVIDER=anthropic # uses ANTHROPIC_API_KEY
```

---

## Session Persistence

- Each browser session calls `POST /sessions` → gets `session_id`
- All messages written to `messages` table with `session_id` FK
- Enables multi-turn context retrieval in Phase 4
