# Design: The Lenny Growth Assistant UI

## Design Principles
- **Dark-first**: Deep navy/charcoal base (#0d0f14), reduces eye strain for long sessions
- **Dual-panel**: Chat left, Artifact history right — mirrors IDE-style artifact workflows
- **Zero-friction mode switching**: Skill buttons in sidebar; no page reload
- **Artifact-first thinking**: Every LLM response is a structured artifact with type badge + copy action

---

## Color Palette

| Token | Value | Usage |
|-------|-------|-------|
| `--bg` | `#0d0f14` | Page background |
| `--surface` | `#161b24` | Sidebar, artifact panel |
| `--surface2` | `#1e2535` | Message bubbles, inputs |
| `--accent` | `#4f8ef7` | Primary actions, skill active state |
| `--accent2` | `#7c5cfc` | User avatar, gradient endpoints |
| `--success` | `#34d399` | Citation tags |
| `--muted` | `#7a8499` | Placeholder, secondary text |

---

## Layout

```
┌────────────┬────────────────────────────┬──────────────┐
│  Sidebar   │       Chat Area            │  Artifacts   │
│  260px     │    max-width: 720px        │   380px      │
│            │                            │              │
│ [RAG]      │  [avatar] bubble           │ ┌──────────┐ │
│ [Ship30]   │  [avatar] artifact-card    │ │ type     │ │
│            │      ├ type badge          │ │ snippet  │ │
│            │      ├ content             │ └──────────┘ │
│            │      └ citations           │              │
│            │  [textarea] [Send ↑]       │              │
└────────────┴────────────────────────────┴──────────────┘
```

---

## Artifact Card Anatomy

```
┌─────────────────────────────────┐
│ [ship30_essay]         [Copy]   │  ← artifact-header
├─────────────────────────────────┤
│ Essay body / RAG answer text    │  ← artifact-body (pre-wrap)
├─────────────────────────────────┤
│ 📌 Episode 12   📌 Newsletter 3 │  ← citations (RAG only)
└─────────────────────────────────┘
```

---

## Interaction Details

- **Enter** submits message; **Shift+Enter** = newline
- Copy button: `navigator.clipboard` with "Copied!" feedback (1.5s)
- Mode switch: updates placeholder, mode badge, API endpoint
- Artifact panel auto-prepends newest artifact at top
- Messages fade-in with `translateY(8px) → 0` animation (200ms)

---

## Artifact Security Model

Artifacts are rendered via a strict sandboxing strategy:

1. **`DOMPurify.sanitize()`**: All LLM output is sanitized before being inserted into the DOM. `<script>`, `onerror`, and malicious SVG payloads are stripped.
2. **`marked.js`**: Markdown is rendered to HTML, then piped through DOMPurify.
3. **Sandboxed `<iframe>`**: Rendered HTML is injected into an iframe using `srcdoc`.
   - The iframe is configured with `sandbox="allow-scripts"`.
   - **Crucially**, `allow-same-origin` is omitted. This guarantees the iframe cannot access `localStorage`, cookies, or the parent `window` object, even if a script somehow bypassed DOMPurify.
4. **CSP**: A `Content-Security-Policy` header restricts external scripts and fonts to trusted CDNs (JSDelivr, Google Fonts).
