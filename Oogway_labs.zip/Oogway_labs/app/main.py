from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session as DbSession
from pydantic import BaseModel
from typing import List, Optional
import os

from .models import Base, Session, Message, Artifact
from .core.llm import llm, LLMError, OllamaUnavailableError, MissingAPIKeyError, ModelTimeoutError
from .core.agent import lenny_agent
from .services.ship30 import generate_ship30_essay
from .services.rag import rag_service

import time
import logging

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:password@localhost:5432/lenny_db"
)

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Wait for DB to be ready
max_retries = 5
for i in range(max_retries):
    try:
        Base.metadata.create_all(bind=engine)
        break
    except Exception as e:
        if i == max_retries - 1:
            raise e
        logging.warning(f"Database not ready yet, retrying in 2 seconds... ({e})")
        time.sleep(2)

app = FastAPI(title="The Lenny Growth Assistant API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ------------------------------------------------------------------ #
# Pydantic schemas                                                      #
# ------------------------------------------------------------------ #

class SessionCreateResponse(BaseModel):
    session_id: str

class MessageCreate(BaseModel):
    role: str
    content: str

class MessageResponse(BaseModel):
    id: str
    role: str
    content: str

class ChatRequest(BaseModel):
    session_id: str
    query: str

class Ship30Request(BaseModel):
    session_id: str
    topic: str
    context: Optional[str] = None

class SourceRef(BaseModel):
    source: str
    chunk_index: int = 0
    score: float = 0.0

class ArtifactSchema(BaseModel):
    artifact_type: str
    format: str = "markdown"
    title: str = ""
    content: str

class ChatResponse(BaseModel):
    session_id: str
    answer: str
    sources: List[SourceRef] = []
    artifact: Optional[ArtifactSchema] = None
    provider: str


# ------------------------------------------------------------------ #
# Session endpoints                                                     #
# ------------------------------------------------------------------ #

@app.post("/sessions", response_model=SessionCreateResponse)
def create_session(db: DbSession = Depends(get_db)):
    new_session = Session()
    db.add(new_session)
    db.commit()
    db.refresh(new_session)
    return {"session_id": new_session.id}


@app.get("/sessions/{session_id}/messages", response_model=List[MessageResponse])
def get_messages(session_id: str, db: DbSession = Depends(get_db)):
    session = db.query(Session).filter(Session.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session.messages


@app.post("/sessions/{session_id}/messages", response_model=MessageResponse)
def add_message(session_id: str, message: MessageCreate, db: DbSession = Depends(get_db)):
    session = db.query(Session).filter(Session.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    new_message = Message(
        session_id=session_id, role=message.role, content=message.content
    )
    db.add(new_message)
    db.commit()
    db.refresh(new_message)
    return new_message


# ------------------------------------------------------------------ #
# Provider info                                                         #
# ------------------------------------------------------------------ #

@app.get("/api/provider")
def get_provider():
    return {"provider": llm.get_provider_name()}


# ------------------------------------------------------------------ #
# Session-aware chat flow                                               #
# ------------------------------------------------------------------ #

def _get_validated_session(session_id: str, db: DbSession) -> Session:
    session = db.query(Session).filter(Session.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")
    return session


def _load_history(session: Session) -> list:
    """Convert DB messages to agent-compatible history list."""
    return [
        {"role": m.role, "content": m.content}
        for m in session.messages
    ]


def _save_turn(
    db: DbSession,
    session_id: str,
    user_query: str,
    assistant_answer: str,
):
    """Persist both turns atomically."""
    db.add(Message(session_id=session_id, role="user", content=user_query))
    db.add(Message(session_id=session_id, role="assistant", content=assistant_answer))
    db.commit()


def _save_artifact(
    db: DbSession,
    session_id: str,
    artifact_type: str,
    title: str,
    content: str,
    fmt: str,
    sources: list,
) -> Artifact:
    a = Artifact(
        session_id=session_id,
        artifact_type=artifact_type,
        format=fmt,
        title=title,
        content=content,
        sources=sources,
    )
    db.add(a)
    db.commit()
    db.refresh(a)
    return a


def _handle_llm_error(e: Exception):
    if isinstance(e, OllamaUnavailableError):
        raise HTTPException(
            status_code=503,
            detail=f"Ollama is unavailable: {e}. Run `ollama serve`."
        )
    if isinstance(e, MissingAPIKeyError):
        raise HTTPException(
            status_code=401,
            detail=f"LLM credentials missing: {e}"
        )
    if isinstance(e, ModelTimeoutError):
        raise HTTPException(status_code=504, detail=f"LLM timed out: {e}")
    raise HTTPException(status_code=500, detail=f"LLM error: {e}")


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest, db: DbSession = Depends(get_db)):
    """
    Session-aware RAG chat.

    Flow:
    1. Validate session
    2. Load conversation history (session-scoped)
    3. Route through LennyAgent (RAG retrieval + optional tool calls)
    4. Persist user message + assistant response
    5. Persist artifact if generated
    6. Return answer, sources, artifact
    """
    session = _get_validated_session(req.session_id, db)
    history = _load_history(session)

    try:
        agent_resp = lenny_agent.chat(query=req.query, history=history)
    except LLMError as e:
        _handle_llm_error(e)

    _save_turn(db, req.session_id, req.query, agent_resp.answer)

    artifact_schema = None
    if agent_resp.artifact:
        a = agent_resp.artifact
        db_artifact = _save_artifact(
            db,
            session_id=req.session_id,
            artifact_type=a.artifact_type,
            title=a.title,
            content=a.content,
            fmt=a.format,
            sources=agent_resp.sources,
        )
        artifact_schema = ArtifactSchema(
            artifact_type=db_artifact.artifact_type,
            format=db_artifact.format,
            title=db_artifact.title,
            content=db_artifact.content,
        )

    return ChatResponse(
        session_id=req.session_id,
        answer=agent_resp.answer,
        sources=[SourceRef(**s) for s in agent_resp.sources],
        artifact=artifact_schema,
        provider=llm.get_provider_name(),
    )


@app.post("/api/chat/ship30", response_model=ChatResponse)
def chat_ship30(req: Ship30Request, db: DbSession = Depends(get_db)):
    """
    Session-aware Ship 30 for 30 essay generation.

    Retrieves relevant transcript context first, then generates grounded essay.
    """
    session = _get_validated_session(req.session_id, db)
    history = _load_history(session)

    # Retrieve context to ground the essay
    docs = rag_service.retrieve(req.topic)
    context_text = None
    sources = []
    if docs:
        context_text = "\n\n".join(
            f"[{d['source']}]\n{d['text']}" for d in docs
        )
        sources = [
            {"source": d["source"], "chunk_index": d["chunk_index"], "score": d["score"]}
            for d in docs
        ]

    try:
        result = generate_ship30_essay(
            topic=req.topic,
            context=context_text or req.context,
        )
    except LLMError as e:
        _handle_llm_error(e)

    answer = f"Here's your Ship 30 for 30 essay on **{result['topic']}** (~{result['word_count']} words)."

    _save_turn(db, req.session_id, f"[Ship30] {req.topic}", answer)

    db_artifact = _save_artifact(
        db,
        session_id=req.session_id,
        artifact_type="ship30_essay",
        title=f"Ship 30 Essay: {result['topic']}",
        content=result["content"],
        fmt="markdown",
        sources=sources,
    )

    return ChatResponse(
        session_id=req.session_id,
        answer=answer,
        sources=[SourceRef(**s) for s in sources],
        artifact=ArtifactSchema(
            artifact_type="ship30_essay",
            format="markdown",
            title=db_artifact.title,
            content=result["content"],
        ),
        provider=llm.get_provider_name(),
    )


# ------------------------------------------------------------------ #
# Health                                                                #
# ------------------------------------------------------------------ #

@app.get("/health")
def health_check():
    return {"status": "ok", "provider": llm.get_provider_name()}
