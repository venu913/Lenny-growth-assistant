from sqlalchemy import Column, String, DateTime, ForeignKey, JSON, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import datetime
import uuid

Base = declarative_base()


def _uuid():
    return str(uuid.uuid4())


class Session(Base):
    __tablename__ = 'sessions'

    id = Column(String, primary_key=True, default=_uuid)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    user_metadata = Column(JSON, default={})

    messages = relationship("Message", back_populates="session", order_by="Message.created_at")
    artifacts = relationship("Artifact", back_populates="session")


class Message(Base):
    __tablename__ = 'messages'

    id = Column(String, primary_key=True, default=_uuid)
    session_id = Column(String, ForeignKey('sessions.id'), nullable=False)
    role = Column(String, nullable=False)   # 'user' | 'assistant'
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    session = relationship("Session", back_populates="messages")


class Artifact(Base):
    __tablename__ = 'artifacts'

    id = Column(String, primary_key=True, default=_uuid)
    session_id = Column(String, ForeignKey('sessions.id'), nullable=False)
    artifact_type = Column(String, nullable=False)   # 'rag_answer' | 'ship30_essay' | 'markdown' | 'html'
    format = Column(String, default='markdown')       # 'markdown' | 'html'
    title = Column(String, default='')
    content = Column(Text, nullable=False)
    sources = Column(JSON, default=[])               # list of source dicts
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    session = relationship("Session", back_populates="artifacts")
