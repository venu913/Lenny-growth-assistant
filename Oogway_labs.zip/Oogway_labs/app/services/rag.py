"""
RAGService — Retrieval-Augmented Generation over Lenny's transcript corpus.

Retrieval:
  - Primary: ChromaDB vector store (populated by scripts/ingest.py)
  - Fallback: static stub KB if ChromaDB collection is empty

Low-confidence contract:
  - If no chunks are retrieved OR max relevance score < CONFIDENCE_THRESHOLD,
    the assistant explicitly declines to fabricate an answer.

Source tracing:
  - Every retrieved chunk carries {source, chunk_index, score} metadata.
  - This is passed through to the API response for frontend citation display.
"""

import os
from typing import List, Dict, Tuple, Optional

CONFIDENCE_THRESHOLD = 0.30   # cosine distance; lower = more similar in ChromaDB
CHROMADB_PATH = os.getenv("CHROMADB_PATH", "./chroma_db")
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "lenny_transcripts")
TOP_K = int(os.getenv("RAG_TOP_K", "5"))

LOW_CONFIDENCE_REPLY = (
    "I don't have sufficient evidence in Lenny's transcripts to reliably answer this. "
    "Try rephrasing, or check that the knowledge base has been seeded with relevant transcripts."
)

# Static stub — used when ChromaDB is empty (pre-ingestion)
_STUB_KB = [
    {
        "id": "stub_1",
        "text": (
            "Lenny Rachitsky: The most important thing for early-stage growth is finding "
            "your activation moment — the first time a user experiences real value from your product. "
            "For Slack it was 2,000 messages sent. For Dropbox it was one file on two devices."
        ),
        "source": "stub:Episode 1 — Growth Fundamentals",
        "chunk_index": 0,
    },
    {
        "id": "stub_2",
        "text": (
            "Lenny on retention: Retention is the foundation of all growth. "
            "If you can't retain users, acquisition spend is wasted. "
            "Focus on the D1, D7, D30 retention curve before investing in paid growth."
        ),
        "source": "stub:Newsletter #45 — Retention Curves",
        "chunk_index": 0,
    },
    {
        "id": "stub_3",
        "text": (
            "Lenny Rachitsky on North Star Metrics: Every team should align around a single "
            "metric that best captures delivered customer value. Revenue is a lagging indicator. "
            "Pick a leading metric — messages sent, nights booked, files stored."
        ),
        "source": "stub:Episode 89 — North Star Metrics with Shreyas Doshi",
        "chunk_index": 0,
    },
]


def _load_chroma():
    """Attempt to load ChromaDB collection. Returns (collection, available: bool)."""
    try:
        import chromadb
        client = chromadb.PersistentClient(path=CHROMADB_PATH)
        col = client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        return col, True
    except Exception:
        return None, False


class RAGService:
    def __init__(self):
        self._collection, self._chroma_available = _load_chroma()

    def retrieve(self, query: str) -> List[Dict]:
        """
        Return top-k chunks relevant to query.
        Each chunk: {text, source, chunk_index, score}
        score: 0.0 = identical, 1.0 = completely dissimilar (ChromaDB cosine distance)
        """
        if self._chroma_available and self._collection is not None:
            try:
                count = self._collection.count()
                if count > 0:
                    results = self._collection.query(
                        query_texts=[query],
                        n_results=min(TOP_K, count),
                        include=["documents", "metadatas", "distances"],
                    )
                    docs = []
                    for text, meta, dist in zip(
                        results["documents"][0],
                        results["metadatas"][0],
                        results["distances"][0],
                    ):
                        docs.append({
                            "text": text,
                            "source": meta.get("source", "unknown"),
                            "chunk_index": meta.get("chunk_index", 0),
                            "score": round(1.0 - dist, 4),  # convert distance → similarity
                        })
                    return docs
            except Exception:
                pass  # fall through to empty or stub

        # Only use stub if explicitly enabled for demo purposes
        if os.getenv("LENNY_STUB_MODE", "false").lower() == "true":
            return [
                {
                    "text": d["text"],
                    "source": d["source"] + " [DEMO DATA — not a real transcript]",
                    "chunk_index": d["chunk_index"],
                    "score": 0.5,  # nominal score for stubs
                }
                for d in _STUB_KB
            ]
        
        # Safe default: return no context
        return []

    def answer_question(
        self, query: str, history: Optional[List[Dict]] = None
    ) -> Tuple[str, List[Dict]]:
        """
        Retrieve context, check confidence, generate grounded answer.

        Returns:
            (answer: str, sources: List[{source, chunk_index, score}])
        """
        docs = self.retrieve(query)

        # Low-confidence gate
        if not docs or max(d["score"] for d in docs) < CONFIDENCE_THRESHOLD:
            return LOW_CONFIDENCE_REPLY, []

        from app.core.llm import llm

        context = "\n\n".join(
            f"[{d['source']}]\n{d['text']}" for d in docs
        )
        sources = [
            {"source": d["source"], "chunk_index": d["chunk_index"], "score": d["score"]}
            for d in docs
        ]

        system_prompt = (
            "You are The Lenny Growth Assistant. Answer ONLY using the provided context. "
            "Cite your sources inline using [Source Name]. "
            "If the context doesn't contain a clear answer, say: "
            f'"{LOW_CONFIDENCE_REPLY}"'
        )
        prompt = f"Context:\n{context}\n\nQuestion: {query}"

        answer = llm.generate(prompt=prompt, system_prompt=system_prompt)
        return answer, sources


rag_service = RAGService()
