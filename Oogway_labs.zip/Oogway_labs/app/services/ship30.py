"""
Ship 30 for 30 Skill — Atomic Essay Generator

Writing principles encoded from the Ship 30 for 30 framework by Dickie Bush & Nicolas Cole,
applied to Lenny Rachitsky's growth and product management domain.

Source: https://www.ship30for30.com/post/how-to-write-atomic-essays

Principles:
  1. Hook — specific, contrarian, or counterintuitive opening line
  2. ABT narrative — And / But / Therefore story spine
  3. ~1,250 words (full essay mode); <250 words (atomic mode)
  4. Headings every 200-300 words
  5. Bullets for lists of 3+ items
  6. Selective **bold** for key terms (≤1 per paragraph)
  7. Specific, actionable takeaway at the end
  8. Claims grounded in retrieved transcript context where available
  9. Twitter/X thread hook + 30-day topic ladder as appendix
"""

from dataclasses import dataclass
from typing import Optional

# Ship30 writing principles injected into system prompt
_SHIP30_PRINCIPLES = """
You are writing a Ship 30 for 30 Atomic Essay following these rules:

STRUCTURE (must follow exactly):
1. HOOK (first sentence): Specific, counterintuitive, or surprising — NOT generic.
   Examples: "Most PMs measure the wrong thing." / "Activation is not onboarding."
2. SETUP (1 paragraph): Context and why this matters. Use "And..." to expand.
3. PROBLEM (1 paragraph): The tension or mistake people make. Use "But..." to introduce.
4. SOLUTION (2-3 sections with ## headings): Clear, numbered or bulleted steps.
   Use "Therefore..." to frame the resolution.
5. EVIDENCE (inline): Reference specific Lenny episodes, guests, or newsletter numbers.
6. TAKEAWAY (final paragraph): One specific, actionable sentence the reader can use today.

FORMATTING RULES:
- Target: ~1,250 words (10-15 paragraphs)
- Use ## headings every 200-300 words
- Use bullet lists for 3+ parallel items
- Bold (**word**) at most one term per paragraph
- No filler phrases: "In conclusion", "As we can see", "It's important to note"
- No generic advice: "Focus on the customer" without specifics

APPENDIX (after main essay):
---
## Twitter/X Thread Hook
[Write a compelling single-sentence tweet hook for this essay]

## 30-Day Topic Ladder
[List 10 related Atomic Essay topics that could follow this one]
"""

_GROUNDING_INSTRUCTION = """
GROUNDING RULE:
The following context has been retrieved from Lenny's actual podcast transcripts and newsletters.
You MUST reference at least 2 specific pieces of evidence from this context inline.

Retrieved context:
{context}
"""


@dataclass
class Ship30Artifact:
    topic: str
    content: str
    word_count: int
    artifact_type: str = "ship30_essay"
    metadata: dict = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {
                "framework": "Ship 30 for 30",
                "target_words": 1250,
                "author_style": "Lenny Rachitsky domain",
            }


def generate_ship30_essay(
    topic: str,
    context: Optional[str] = None,
) -> dict:
    """
    Generate a ~1,250 word Ship 30 for 30 Atomic Essay.

    Args:
        topic:   The essay topic (e.g. "user activation in B2B SaaS")
        context: Optional retrieved transcript chunks to ground the essay

    Returns:
        dict with keys: topic, content, artifact_type, word_count, metadata
    """
    from app.core.llm import llm

    grounding = ""
    if context:
        grounding = _GROUNDING_INSTRUCTION.format(context=context)
    else:
        grounding = (
            "\nNo specific transcript context was retrieved. "
            "You MUST state that there is insufficient data in the knowledge base. "
            "Do NOT fabricate episode numbers, guests, or Lenny quotes.\n"
        )

    system_prompt = _SHIP30_PRINCIPLES + grounding

    prompt = (
        f"Write a Ship 30 for 30 Atomic Essay on this topic:\n\n"
        f"**{topic}**\n\n"
        f"Follow the structure and formatting rules exactly. "
        f"Target ~1,250 words. Include the Twitter hook and 10-topic ladder at the end."
    )

    content = llm.generate(prompt=prompt, system_prompt=system_prompt)
    word_count = len(content.split())
    
    # Word count retry logic
    retries = 0
    max_retries = 2
    while word_count < 900 and retries < max_retries:
        retry_prompt = (
            f"{content}\n\n"
            f"---\n"
            f"The essay above is only {word_count} words. It needs to be closer to 1,250 words. "
            f"Please expand on the solution steps with more depth, examples, and analysis to reach the word count target. "
            f"Output the ENTIRE expanded essay from the beginning, including the appendix."
        )
        content = llm.generate(prompt=retry_prompt, system_prompt=system_prompt)
        word_count = len(content.split())
        retries += 1

    artifact = Ship30Artifact(
        topic=topic,
        content=content,
        word_count=word_count,
    )

    return {
        "topic": artifact.topic,
        "content": artifact.content,
        "word_count": artifact.word_count,
        "artifact_type": artifact.artifact_type,
        "metadata": artifact.metadata,
    }
