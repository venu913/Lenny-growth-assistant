import os
import requests


class LLMError(Exception):
    """Base class for LLM provider errors."""


class OllamaUnavailableError(LLMError):
    """Raised when Ollama server is not reachable."""


class MissingAPIKeyError(LLMError):
    """Raised when a required API key is absent."""


class ModelTimeoutError(LLMError):
    """Raised when the LLM exceeds the configured timeout."""


class LLMProvider:
    def __init__(self):
        self.provider = os.getenv("LLM_PROVIDER", "ollama")
        self.ollama_url = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
        self.ollama_model = os.getenv("OLLAMA_MODEL", "llama3")
        self.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
        self.timeout = int(os.getenv("LLM_TIMEOUT_SECONDS", "60"))

    def get_provider_name(self) -> str:
        if self.provider == "anthropic":
            return "Anthropic Claude (SDK)"
        return f"Ollama ({self.ollama_model})"

    def generate(self, prompt: str, system_prompt: str = "") -> str:
        if self.provider == "anthropic":
            return self._call_anthropic(prompt, system_prompt)
        return self._call_ollama(prompt, system_prompt)

    def generate_with_tools(self, messages: list, tools: list, system_prompt: str = "") -> dict:
        """
        Invoke Claude with tool definitions via the official anthropic SDK.
        Returns a response dict compatible with the agent loop in agent.py.
        Falls back to plain generate() on Ollama (no native tool-call support).

        Uses: anthropic.Anthropic().messages.create() with tools= parameter.
        This is the official Anthropic Claude SDK agent loop pattern.
        """
        if self.provider == "anthropic":
            return self._call_anthropic_tools(messages, tools, system_prompt)
        # Ollama fallback: inject tool descriptions into the prompt
        tool_desc = "\n".join(
            f"- {t['name']}: {t['description']}" for t in tools
        )
        combined = (
            f"{system_prompt}\n\nAvailable tools:\n{tool_desc}\n\n"
            + "\n".join(f"{m['role'].upper()}: {m['content']}" for m in messages)
        )
        text = self._call_ollama(combined, "")
        return {"type": "text", "content": text}

    # ------------------------------------------------------------------ #
    # Private helpers                                                       #
    # ------------------------------------------------------------------ #

    def _call_ollama(self, prompt: str, system_prompt: str) -> str:
        payload = {
            "model": self.ollama_model,
            "prompt": f"{system_prompt}\n\n{prompt}" if system_prompt else prompt,
            "stream": False,
        }
        try:
            response = requests.post(self.ollama_url, json=payload, timeout=self.timeout)
            response.raise_for_status()
            return response.json().get("response", "")
        except requests.exceptions.ConnectionError as e:
            raise OllamaUnavailableError(
                f"Cannot reach Ollama at {self.ollama_url}. "
                "Run `ollama serve` and ensure the model is pulled."
            ) from e
        except requests.exceptions.Timeout as e:
            raise ModelTimeoutError(
                f"Ollama did not respond within {self.timeout}s."
            ) from e

    def _call_anthropic(self, prompt: str, system_prompt: str) -> str:
        """Text generation via the official Anthropic Python SDK (anthropic.Anthropic client)."""
        if not self.anthropic_api_key:
            raise MissingAPIKeyError(
                "ANTHROPIC_API_KEY is not set. "
                "Export it or switch LLM_PROVIDER=ollama."
            )
        try:
            import anthropic as _sdk
        except ImportError:
            raise LLMError("anthropic package not installed. Run: pip install anthropic")
        try:
            client = _sdk.Anthropic(api_key=self.anthropic_api_key)
            kwargs = {
                "model": "claude-3-haiku-20240307",
                "max_tokens": 2048,
                "messages": [{"role": "user", "content": prompt}],
            }
            if system_prompt:
                kwargs["system"] = system_prompt
            message = client.messages.create(**kwargs)
            return message.content[0].text
        except _sdk.AuthenticationError as e:
            raise MissingAPIKeyError("Anthropic API key is invalid or expired.") from e
        except _sdk.APITimeoutError as e:
            raise ModelTimeoutError(f"Anthropic API did not respond within {self.timeout}s.") from e
        except _sdk.APIError as e:
            raise LLMError(f"Anthropic API error: {e}") from e

    def _call_anthropic_tools(self, messages: list, tools: list, system_prompt: str) -> dict:
        """
        Tool-calling agentic loop via the official Anthropic Python SDK.

        anthropic.Anthropic().messages.create(tools=[...]) is the SDK-provided
        mechanism for building Claude agent loops with tool use.

        Returns a dict compatible with the existing agent loop in agent.py.
        """
        if not self.anthropic_api_key:
            raise MissingAPIKeyError("ANTHROPIC_API_KEY is not set.")
        try:
            import anthropic as _sdk
        except ImportError:
            raise LLMError("anthropic package not installed. Run: pip install anthropic")
        try:
            client = _sdk.Anthropic(api_key=self.anthropic_api_key)
            kwargs = {
                "model": "claude-3-haiku-20240307",
                "max_tokens": 2048,
                "tools": tools,
                "messages": messages,
            }
            if system_prompt:
                kwargs["system"] = system_prompt
            message = client.messages.create(**kwargs)
            # Convert SDK response object to plain dict for agent.py compatibility
            return {
                "stop_reason": message.stop_reason,
                "content": [_sdk_block_to_dict(block) for block in message.content],
            }
        except _sdk.AuthenticationError as e:
            raise MissingAPIKeyError("Anthropic API key is invalid or expired.") from e
        except _sdk.APITimeoutError as e:
            raise ModelTimeoutError(f"Anthropic API timed out after {self.timeout}s.") from e
        except _sdk.APIError as e:
            raise LLMError(f"Anthropic API error: {e}") from e


def _sdk_block_to_dict(block) -> dict:
    """Convert an anthropic SDK content block object to a plain dict."""
    block_type = getattr(block, "type", None)
    if block_type == "text":
        return {"type": "text", "text": block.text}
    if block_type == "tool_use":
        return {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
    return {"type": str(block_type)}


llm = LLMProvider()