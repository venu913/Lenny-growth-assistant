"""
LennyAgent — Anthropic Claude tool-calling agent with three bounded capabilities:

  1. rag_retrieve   — query Lenny's transcript knowledge base
  2. ship30_write   — generate a Ship 30 for 30 Atomic Essay (~1,250 words)
  3. generate_artifact — package content as a typed, titled artifact

Why Anthropic tool-calling (not a separate agent SDK):
- The assignment requires clear tool/skill boundaries; Claude's native tools API
  enforces this via JSON schema validation and model-driven routing.
- No additional framework dependency — we already support Anthropic in llm.py.
- Ollama fallback works via structured-prompt routing when tool calling is
  unavailable (e.g., base llama3).
"""

import json
from typing import Optional
from dataclasses import dataclass, field

from .llm import llm, LLMError

# ------------------------------------------------------------------ #
# Tool schemas (Anthropic format)                                      #
# ------------------------------------------------------------------ #

TOOLS = [
    {
        "name": "rag_retrieve",
        "description": (
            "Search Lenny Rachitsky's podcast transcripts and newsletters for information "
            "relevant to the user's question. Returns grounded text chunks with source citations."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's question or search query"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "ship30_write",
        "description": (
            "Generate a Ship 30 for 30 Atomic Essay (~1,250 words) on a given topic, "
            "grounded in retrieved Lenny transcript context where available."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "The essay topic"},
                "context": {
                    "type": "string",
                    "description": "Optional retrieved transcript context to ground the essay",
                },
            },
            "required": ["topic"],
        },
    },
    {
        "name": "generate_artifact",
        "description": (
            "Package a piece of content as a structured artifact with a type, title, and format."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "artifact_type": {
                    "type": "string",
                    "enum": ["rag_answer", "ship30_essay", "markdown", "html"],
                },
                "title": {"type": "string"},
                "content": {"type": "string"},
                "format": {"type": "string", "enum": ["markdown", "html"], "default": "markdown"},
            },
            "required": ["artifact_type", "title", "content"],
        },
    },
]

AGENT_SYSTEM_PROMPT = """You are The Lenny Growth Assistant — an expert on Lenny Rachitsky's
product growth frameworks, podcast insights, and newsletter content.

You have access to three tools:
1. rag_retrieve — always call this first to ground your answer in Lenny's actual content.
2. ship30_write — call when the user wants a Ship 30 for 30 essay.
3. generate_artifact — call to produce a structured artifact after generating content.

Rules:
- ALWAYS call rag_retrieve before answering questions about Lenny's content.
- If retrieval returns no relevant context, honestly say so instead of inventing content.
- When answering questions, call generate_artifact with type 'rag_answer'.
- When writing essays, call generate_artifact with type 'ship30_essay'.
- Keep your text responses concise; put detailed content inside artifacts."""


@dataclass
class AgentArtifact:
    artifact_type: str
    title: str
    content: str
    format: str = "markdown"
    sources: list = field(default_factory=list)


@dataclass
class AgentResponse:
    answer: str
    sources: list = field(default_factory=list)
    artifact: Optional[AgentArtifact] = None
    tool_calls_made: list = field(default_factory=list)


# ------------------------------------------------------------------ #
# LennyAgent                                                           #
# ------------------------------------------------------------------ #

class LennyAgent:
    def __init__(self):
        # Lazy imports to avoid circular deps
        from app.services.rag import rag_service
        from app.services.ship30 import generate_ship30_essay
        self._rag = rag_service
        self._ship30 = generate_ship30_essay

    def chat(
        self,
        query: str,
        history: Optional[list] = None,
    ) -> AgentResponse:
        """
        Route the user query through the agent.

        Args:
            query:   The user's latest message.
            history: List of {"role": "user"|"assistant", "content": str} dicts
                     representing prior turns in this session.

        Returns:
            AgentResponse with answer, sources, and optional artifact.
        """
        history = history or []
        messages = history + [{"role": "user", "content": query}]

        if llm.provider == "anthropic":
            return self._run_anthropic(messages)
        else:
            return self._run_ollama_fallback(query, messages)

    # ------------------------------------------------------------------ #
    # Anthropic path (native tool-calling)                                 #
    # ------------------------------------------------------------------ #

    def _run_anthropic(self, messages: list) -> AgentResponse:
        tool_calls_made = []
        sources = []
        artifact = None
        retrieved_context = ""
        max_iterations = 5  # guard against infinite loops

        for _ in range(max_iterations):
            raw = llm.generate_with_tools(
                messages=messages,
                tools=TOOLS,
                system_prompt=AGENT_SYSTEM_PROMPT,
            )
            stop_reason = raw.get("stop_reason", "end_turn")

            if stop_reason == "tool_use":
                # Process each tool call in this turn
                assistant_content = raw.get("content", [])
                messages.append({"role": "assistant", "content": assistant_content})
                tool_results = []

                for block in assistant_content:
                    if block.get("type") != "tool_use":
                        continue
                    tool_name = block["name"]
                    tool_input = block.get("input", {})
                    tool_id = block["id"]
                    tool_calls_made.append(tool_name)

                    result_content = self._dispatch_tool(
                        tool_name, tool_input, sources
                    )
                    if tool_name == "rag_retrieve":
                        retrieved_context = result_content
                    if tool_name == "generate_artifact":
                        try:
                            adict = json.loads(result_content)
                            artifact = AgentArtifact(
                                artifact_type=adict.get("artifact_type", "markdown"),
                                title=adict.get("title", ""),
                                content=adict.get("content", ""),
                                format=adict.get("format", "markdown"),
                                sources=sources,
                            )
                        except Exception:
                            pass

                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_id,
                        "content": result_content,
                    })

                messages.append({"role": "user", "content": tool_results})

            else:
                # end_turn — extract final text
                final_text = ""
                for block in raw.get("content", []):
                    if isinstance(block, dict) and block.get("type") == "text":
                        final_text += block.get("text", "")
                    elif isinstance(block, str):
                        final_text += block
                return AgentResponse(
                    answer=final_text.strip(),
                    sources=sources,
                    artifact=artifact,
                    tool_calls_made=tool_calls_made,
                )

        return AgentResponse(
            answer="I reached the maximum reasoning steps. Please try a simpler question.",
            sources=sources,
            artifact=artifact,
            tool_calls_made=tool_calls_made,
        )

    # ------------------------------------------------------------------ #
    # Ollama fallback (structured-prompt routing)                          #
    # ------------------------------------------------------------------ #

    def _run_ollama_fallback(self, query: str, messages: list) -> AgentResponse:
        """
        Detect intent from query, call appropriate service, wrap result.
        Used when Ollama model doesn't support native tool-calling.
        """
        tool_calls_made = []
        sources = []
        artifact = None
        query_lower = query.lower()

        is_ship30 = any(kw in query_lower for kw in [
            "ship 30", "atomic essay", "write an essay", "essay on", "essay about"
        ])

        if is_ship30:
            tool_calls_made.append("rag_retrieve")
            docs = self._rag.retrieve(query)
            context = None
            if docs:
                context = "\n\n".join(f"[{d['source']}]\n{d['text']}" for d in docs)
                for d in docs:
                    sources.append({"source": d["source"], "chunk_index": d.get("chunk_index", 0)})
            
            tool_calls_made.append("ship30_write")
            # Extract topic — use query minus trigger words
            topic = query
            result = self._ship30(topic=topic, context=context)
            artifact = AgentArtifact(
                artifact_type="ship30_essay",
                title=f"Ship 30 Essay: {result['topic']}",
                content=result["content"],
                format="markdown",
                sources=sources,
            )
            return AgentResponse(
                answer=f"Here's your Ship 30 for 30 Atomic Essay on **{result['topic']}**.",
                sources=sources,
                artifact=artifact,
                tool_calls_made=tool_calls_made,
            )

        # Default: RAG
        tool_calls_made.append("rag_retrieve")
        answer, sources = self._rag.answer_question(query)
        tool_calls_made.append("generate_artifact")
        artifact = AgentArtifact(
            artifact_type="rag_answer",
            title=f"Answer: {query[:60]}",
            content=answer,
            format="markdown",
            sources=sources,
        )
        return AgentResponse(
            answer=answer,
            sources=sources,
            artifact=artifact,
            tool_calls_made=tool_calls_made,
        )

    # ------------------------------------------------------------------ #
    # Tool dispatcher                                                       #
    # ------------------------------------------------------------------ #

    def _dispatch_tool(self, name: str, inputs: dict, sources_accumulator: list) -> str:
        if name == "rag_retrieve":
            docs = self._rag.retrieve(inputs.get("query", ""))
            for d in docs:
                ref = {"source": d["source"], "chunk_index": d.get("chunk_index", 0)}
                if ref not in sources_accumulator:
                    sources_accumulator.append(ref)
            context_lines = [f"[{d['source']}] {d['text']}" for d in docs]
            if not docs:
                return "No relevant content found in the knowledge base."
            return "\n\n".join(context_lines)

        elif name == "ship30_write":
            result = self._ship30(
                topic=inputs.get("topic", ""),
                context=inputs.get("context"),
            )
            return result["content"]

        elif name == "generate_artifact":
            return json.dumps({
                "artifact_type": inputs.get("artifact_type", "markdown"),
                "title": inputs.get("title", ""),
                "content": inputs.get("content", ""),
                "format": inputs.get("format", "markdown"),
            })

        return f"Unknown tool: {name}"


# Singleton
lenny_agent = LennyAgent()
