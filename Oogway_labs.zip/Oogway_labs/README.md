# The Lenny Growth Assistant

A conversational AI assistant grounded in Lenny Rachitsky's podcast transcripts and newsletters, with a pluggable skill system.

---

## Architecture

```
Browser (frontend/index.html)
        │
FastAPI (app/main.py)
   ├── /sessions, /messages          → PostgreSQL
   ├── /api/chat                     → RAGService → ChromaDB + LLM
   └── /api/chat/ship30              → Ship30Service → LLM

LLMProvider (app/core/llm.py)
   ├── Ollama  [local, default]
   └── Anthropic Claude SDK [cloud]
```

---

## Prerequisites

| Requirement | Version |
|-------------|---------|
| Python | 3.11+ |
| Docker + Docker Compose | 24+ |
| Ollama (local mode) | [ollama.ai](https://ollama.ai) |

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `postgresql://postgres:password@localhost:5432/lenny_db` | PostgreSQL connection string |
| `LLM_PROVIDER` | `ollama` | `ollama` or `anthropic` |
| `OLLAMA_URL` | `http://localhost:11434/api/generate` | Ollama API endpoint |
| `OLLAMA_MODEL` | `llama3` | Model to use with Ollama |
| `ANTHROPIC_API_KEY` | _(none)_ | Required if `LLM_PROVIDER=anthropic` |
| `LENNY_STUB_MODE`| `false` | Enable to use fake stub data for demo purposes when no real transcripts exist |

**Copy `.env.example` to `.env` and set values before running.**

---

## Quick Start

### Docker (Full Stack - Recommended)

```bash
docker-compose up --build -d
# API: http://localhost:8000
# Docs: http://localhost:8000/docs
```
*Note for Linux users: You may need to add `extra_hosts: ["host.docker.internal:host-gateway"]` to the `api` service in `docker-compose.yml` if Ollama is running on the host.*

### Local (Ollama)

```bash
# 1. Pull model
ollama pull llama3

# 2. Start database (or run a local Postgres)
docker-compose up -d db

# 3. Install deps
pip install -r requirements.txt

# 4. Run API
uvicorn app.main:app

# 5. Open UI
# Open frontend/index.html in a web browser
```

### Cloud (Anthropic SDK)

```bash
export LLM_PROVIDER=anthropic
export ANTHROPIC_API_KEY=sk-ant-...
uvicorn app.main:app
```

---

## Running Tests

```bash
pip install -r requirements.txt
pytest
```

Test files:

| File | Coverage |
|------|----------|
| `tests/test_agent.py` | Agent tool routing & fallback |
| `tests/test_endpoints.py` | All FastAPI endpoints |
| `tests/test_rag.py` | RAG retrieval + answer generation |
| `tests/test_persistence.py` | PostgreSQL session/message persistence |
| `tests/test_security.py` | Artifact HTML sanitization and security |

---

## Project Structure

```
Oogway_labs/
├── app/
│   ├── main.py              # FastAPI app + all routes (with retry safety)
│   ├── models.py            # SQLAlchemy Session + Message models
│   ├── core/
│   │   ├── agent.py         # LennyAgent tool router 
│   │   └── llm.py           # LLM provider (Ollama / Anthropic SDK)
│   └── services/
│       ├── rag.py           # RAG retrieval + grounded answering
│       └── ship30.py        # Ship 30 for 30 essay generation skill
├── frontend/
│   └── index.html           # Artifact Viewer UI (zero build step)
├── tests/
│   ├── test_agent.py
│   ├── test_endpoints.py
│   ├── test_rag.py
│   ├── test_persistence.py
│   └── test_security.py
├── docs/
│   ├── PRD.md
│   ├── architecture.md
│   └── design.md
├── docker-compose.yml       # Includes DB healthchecks and persistent volumes
├── Dockerfile               # API Container image
├── pytest.ini
└── README.md
```

---

## API Reference

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| `POST` | `/sessions` | — | Create chat session |
| `GET` | `/sessions/{id}/messages` | — | Fetch session history |
| `POST` | `/sessions/{id}/messages` | `{role, content}` | Append message |
| `POST` | `/api/chat` | `{query}` | RAG-grounded answer |
| `POST` | `/api/chat/ship30` | `{topic, context?}` | Ship 30 essay artifact |
| `GET` | `/health` | — | Liveness check |

Interactive docs: `http://localhost:8000/docs`

---

## Transcript Ingestion & Grounding Limitations

To use the Knowledge Base, you MUST ingest real Lenny transcripts (e.g. from the podcast or newsletter). **There are no real transcripts shipped in this repository.**

**If no real transcripts are ingested:**
The assistant will safely decline to answer or state that there is insufficient evidence to fulfill the request. It will **not** fabricate Lenny episode references or guest quotes.

**Demo Mode:**
If you need to test the UI but don't have real transcripts, set `LENNY_STUB_MODE=true` in your `.env`. This activates a small hardcoded stub KB that returns synthetic answers with a visible `[DEMO DATA]` disclaimer. Do not use this in production.

**Ingestion Command:**

Seed the vector store before using RAG mode:

```bash
python scripts/ingest.py --dir transcripts/ --chunk-size 400 --overlap 50
```

| Flag | Default | Description |
|------|---------|-------------|
| `--dir` | `agent_transcripts/` | Directory of `.txt` transcript files |
| `--chunk-size` | `400` | Max characters per chunk |
| `--overlap` | `50` | Character overlap between chunks |
| `--collection` | `lenny_transcripts` | ChromaDB collection name |
| `--db-path` | `/app/chroma_db` (Docker) or `./chroma_db` | Persistent ChromaDB storage path |

Transcripts must be plain `.txt` files. The script uses sentence-boundary splitting and upserts in batches of 100 to avoid memory spikes. Re-running is safe — ChromaDB upsert is idempotent by chunk MD5 ID.
